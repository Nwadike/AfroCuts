<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold text-gray-800">User Dashboard</h2>
    </x-slot>
    <div class="py-12">
        <p>Welcome, regular user!</p>
    </div>
</x-app-layout>
