

<header class="fixed top-0 left-0 right-0 shadow-md z-50 transition-all duration-300"
        x-data="{ scrolled: false, userMenuOpen: false }" 
        x-init="window.addEventListener('scroll', () => { scrolled = window.scrollY > 50; })" 
        :class="{ 'bg-gray-900 bg-opacity-90 backdrop-filter backdrop-blur-lg': scrolled, 'bg-gray-900': !scrolled }"> 
    <nav class="container mx-auto px-4 py-4 flex items-center justify-between">
        
        <a href="<?php echo e(url('/')); ?>" class="flex items-center space-x-2 text-white hover:text-gray-300">
            <span class="flex items-center justify-center flex-shrink-0 w-8 h-8 text-gray-900 rounded-full bg-gradient-to-br from-white via-gray-200 to-white">
                
                <svg class="w-auto h-5 -translate-y-px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span class="text-xl font-bold">AfroCuts</span>
        </a>

        
        

        
        <div class="flex items-center space-x-4">
            <?php if(auth()->guard()->guest()): ?>
                
                <a href="<?php echo e(route('login')); ?>" class="text-gray-300 hover:text-white transition">Login</a>
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="bg-gray-700 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-600 transition">Register</a>
                <?php endif; ?>
            <?php else: ?>
                
                <div class="relative"> 
                    
                    <button @click="userMenuOpen = !userMenuOpen" class="flex items-center text-gray-300 hover:text-white focus:outline-none rounded-full overflow-hidden border-2 border-gray-700 w-10 h-10 justify-center items-center">
                         
                         <i class="fas fa-user-circle text-2xl"></i> 
                    </button>

                    
                    <div x-show="userMenuOpen" @click.away="userMenuOpen = false" x-cloak
                         class="absolute right-0 mt-2 w-48 bg-gray-800 bg-opacity-90 rounded-md shadow-lg py-1 z-20 border border-gray-700"> 
                        <div class="px-4 py-2 text-sm text-gray-200 border-b border-gray-700">
                            Signed in as:<br>
                            <span class="font-semibold"><?php echo e(Auth::user()->name); ?></span>
                        </div>
                         
                         
                        <a href="<?php echo e(route('dashboard')); ?>" class="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 hover:text-white">Dashboard</a> 
                         
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 hover:text-white">Logout</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </nav>
</header>
<?php /**PATH C:\Users\workn\OneDrive\Desktop\Work\AfroCuts\AfroCuts\resources\views/partials/header.blade.php ENDPATH**/ ?>