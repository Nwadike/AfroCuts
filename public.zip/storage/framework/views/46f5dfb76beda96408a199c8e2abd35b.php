<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8 pt-24"> 
    <div class="flex justify-center">
        <div class="w-full max-w-md">
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center"><?php echo e(__('Register')); ?></h2>

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2"><?php echo e(__('Name')); ?></label>
                        <input id="name" type="text" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2"><?php echo e(__('Email Address')); ?></label>
                        <input id="email" type="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label for="password" class="block text-gray-700 text-sm font-bold mb-2"><?php echo e(__('Password')); ?></label>
                        <input id="password" type="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-6">
                        <label for="password-confirm" class="block text-gray-700 text-sm font-bold mb-2"><?php echo e(__('Confirm Password')); ?></label>
                        <input id="password-confirm" type="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="password_confirmation" required autocomplete="new-password">
                    </div>

                    
                    <div class="mb-6" x-data="{ selectedType: '<?php echo e(old('account_type', 'regular')); ?>' }"> 
                        <label class="block text-gray-700 text-sm font-bold mb-2"><?php echo e(__('Account Type')); ?></label>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4"> 

                            
                            <label for="account_type_regular"
                                   class="flex flex-col items-center justify-center p-6 border rounded-lg cursor-pointer transition-all duration-200
                                          "
                                   :class="{ 'border-gray-800 bg-gray-100 shadow-inner': selectedType === 'regular', 'border-gray-300 bg-white hover:border-gray-500': selectedType !== 'regular' }"
                                   @click="selectedType = 'regular'"> 
                                <input type="radio" id="account_type_regular" name="account_type" value="regular" class="hidden" <?php echo e(old('account_type', 'regular') == 'regular' ? 'checked' : ''); ?>> 
                                <i class="fas fa-user text-3xl mb-3" :class="{ 'text-gray-800': selectedType === 'regular', 'text-gray-500': selectedType !== 'regular' }"></i> 
                                <span class="text-lg font-semibold" :class="{ 'text-gray-800': selectedType === 'regular', 'text-gray-700': selectedType !== 'regular' }"><?php echo e(__('Regular')); ?></span>
                                <p class="text-sm text-gray-600 text-center mt-1">Book appointments</p>
                            </label>

                            
                            <label for="account_type_business"
                                   class="flex flex-col items-center justify-center p-6 border rounded-lg cursor-pointer transition-all duration-200"
                                   :class="{ 'border-gray-800 bg-gray-100 shadow-inner': selectedType === 'business', 'border-gray-300 bg-white hover:border-gray-500': selectedType !== 'business' }"
                                   @click="selectedType = 'business'"> 
                                <input type="radio" id="account_type_business" name="account_type" value="business" class="hidden" <?php echo e(old('account_type') == 'business' ? 'checked' : ''); ?>> 
                                <i class="fas fa-store text-3xl mb-3" :class="{ 'text-gray-800': selectedType === 'business', 'text-gray-500': selectedType !== 'business' }"></i> 
                                <span class="text-lg font-semibold" :class="{ 'text-gray-800': selectedType === 'business', 'text-gray-700': selectedType !== 'business' }"><?php echo e(__('Business')); ?></span>
                                <p class="text-sm text-gray-600 text-center mt-1">List your barbershop</p>
                            </label>

                        </div>
                         <?php $__errorArgs = ['account_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    
                    <div class="flex items-center justify-between">
                        <button type="submit" class="bg-gray-800 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            <?php echo e(__('Register')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\workn\OneDrive\Desktop\Work\AfroCuts\AfroCuts\resources\views/auth/register.blade.php ENDPATH**/ ?>