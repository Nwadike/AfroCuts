

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <style>
    .rating-stars .star {
    transition: transform 0.2s, color 0.2s;
    }
    .rating-stars .star:hover {
        transform: scale(1.2);
    }

    </style>

    <div class="container mx-auto px-4 py-8 pt-24 relative overflow-hidden">

    
            <div class="mb-8"> 
                <a href="<?php echo e(route('barbershops.index')); ?>" class="inline-block bg-gray-300 text-gray-800 px-4 py-2 rounded-lg font-medium hover:bg-gray-400 transition">
                    <i class="fas fa-arrow-left mr-2"></i> Back to List
                </a>
        </div>

        
        <div class="absolute inset-0 z-0 opacity-10"
             style="
                background-image: url('https://img.freepik.com/premium-vector/hairdressing-barbershop-tools-seamless-pattern-beauty-salon_341076-314.jpg?w=900');
                background-size: 200px auto;
                background-repeat: repeat;
                background-position: center;
                pointer-events: none;
                filter: blur(0px);
            "></div>

        <div class="relative z-10 max-w-7xl mx-auto space-y-10">

         
            <div class="mb-8 rounded-lg overflow-hidden shadow-sm">
                 
                <?php if($barbershop->logo): ?>
                    <img src="<?php echo e(asset('storage/' . $barbershop->logo)); ?>" alt="<?php echo e($barbershop->name); ?>" class="w-full h-96 object-cover"> 
                <?php else: ?>
                    <div class="w-full h-96 bg-gray-200 flex items-center justify-center text-gray-400 text-6xl">
                        <i class="fas fa-cut"></i>
                    </div>
                <?php endif; ?>
                 
                 
            </div>


            
            <?php if($barbershop->image): ?>
                <img src="<?php echo e(asset('storage/' . $barbershop->image)); ?>" alt="<?php echo e($barbershop->name); ?>"
                     class="w-full h-64 object-cover rounded-lg shadow-lg border border-white/10">
            <?php endif; ?>

            
            <div class="text-center">
                <h1 class="text-4xl font-bold "><?php echo e($barbershop->name); ?></h1>
                <p class="text-gray-300 mt-1"><i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($barbershop->city); ?>, <?php echo e($barbershop->state); ?></p>
            </div>

            
            <div class="bg-gray-800 p-6 rounded-lg flex flex-col md:flex-row justify-between items-center shadow-xl">
                <div>
                    <h2 class="text-2xl font-semibold text-white">Ready to book?</h2>
                    <p class="text-sm text-gray-300">Don't miss your fresh cut at <?php echo e($barbershop->name); ?>.</p>
                </div>
                <a href="<?php echo e(route('bookings.create', $barbershop->id)); ?>"
                   class="mt-4 md:mt-0 bg-yellow-400 text-gray-900 px-6 py-3 font-bold rounded shadow hover:bg-yellow-500">
                    Book Now
                </a>
            </div>

            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

                
                <div class="space-y-8">

                    
                    <div class="bg-white text-gray-800 p-6 rounded-lg shadow">
                        <h2 class="text-xl font-semibold mb-3">About</h2>
                        <p><?php echo e($barbershop->description ?? 'No description available.'); ?></p>
                    </div>

                    
                    <div class="bg-white text-gray-800 p-6 rounded-lg shadow">
                        <h2 class="text-xl font-semibold mb-3">Services</h2>
                        <?php if(is_array($barbershop->services) && count($barbershop->services) > 0): ?>
                            <ul class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <?php $__currentLoopData = $barbershop->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="bg-gray-100 p-3 rounded font-medium"><?php echo e(is_array($service) ? $service['name'] : $service); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-gray-500">No services listed.</p>
                        <?php endif; ?>
                    </div>


                    
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">Rate</h3>
                        
                        <?php if(Auth::check() && Auth::user()->account_type !== 'barbershop'): ?>

                            <form action="<?php echo e(route('barbershop.rate', $barbershop->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="rating-stars mb-2">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa-regular fa-star fa-2x star" data-value="<?php echo e($i); ?>"></i>
                                    <?php endfor; ?>
                                    <input type="hidden" name="rating" id="rating-value" required>
                                </div>

                                <textarea name="comment" class="form-control mb-3" placeholder="Write your comment (optional)" rows="3"></textarea>
                                <button class="btn btn-success" type="submit">Submit Rating</button>
                            </form>
                        <?php endif; ?>
                    </div>

                  
                    <div class="bg-white text-gray-800 p-6 rounded-lg shadow">
                        <h2 class="text-xl font-semibold mb-3">User Reviews</h2>
                        <?php $__empty_1 = true; $__currentLoopData = $barbershop->ratings()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="border-b pb-4 mb-4">
                                <div class="flex justify-between items-center">
                                    <strong><?php echo e($rating->user->name); ?></strong>
                                    <small class="text-gray-500"><?php echo e($rating->created_at->diffForHumans()); ?></small>
                                </div>
                                <div class="text-yellow-500 my-1">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="<?php echo e($i <= $rating->rating ? 'fas' : 'far'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </div>
                                <?php if($rating->comment): ?>
                                    <p class="text-gray-700"><?php echo e($rating->comment); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-500">No reviews yet. Be the first to rate this barbershop!</p>
                        <?php endif; ?>
                    </div>

                </div>

                
                <div class="space-y-8">

                    
                    <div class="bg-white text-gray-800 p-6 rounded-lg shadow">
                        <h2 class="text-xl font-semibold mb-3">Contact Info</h2>
                        <ul class="space-y-2">
                            <li><strong>Phone:</strong> <?php echo e($barbershop->phone ?? 'N/A'); ?></li>
                            <li><strong>Email:</strong> <?php echo e($barbershop->email ?? 'N/A'); ?></li>
                            <li><strong>Website:</strong>
                                <?php if($barbershop->website): ?>
                                    <a href="<?php echo e($barbershop->website); ?>" class="text-blue-600 hover:underline" target="_blank">
                                        <?php echo e($barbershop->website); ?>

                                    </a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </li>
                            <li><strong>Address:</strong> <?php echo e($barbershop->address ?? 'N/A'); ?></li>
                        </ul>

                        
                        <div class="flex items-center space-x-4 mt-4">
                            <?php if($barbershop->website): ?>
                                <a href="<?php echo e($barbershop->website); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fas fa-globe mr-2"></i> Website</a>
                            <?php endif; ?>
                            <?php if($barbershop->instagram): ?>
                                 
                                 <a href="https://www.instagram.com/<?php echo e($barbershop->instagram); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fab fa-instagram mr-2"></i> Instagram</a>
                            <?php endif; ?>
                            <?php if($barbershop->facebook): ?>
                                 
                                 <a href="https://www.facebook.com/<?php echo e($barbershop->facebook); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fab fa-facebook-f mr-2"></i> Facebook</a>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="bg-white text-gray-800 p-6 rounded-lg shadow">
                        <h2 class="text-xl font-semibold mb-3">Operating Hours</h2>
                         <?php if($barbershop->working_hours): ?>
                            <?php $__currentLoopData = $barbershop->working_hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="text-gray-600"><?php echo e(ucfirst($day)); ?>: <?php echo e($hours); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-gray-600">Hours not specified.</p>
                        <?php endif; ?>
                    </div>


                    
    
                        <div class="p-6 rounded-lg shadow bg-gray-200 h-64 rounded-lg flex items-center justify-center text-gray-600">
                            Map Placeholder
                            
                        </div>
         

                    
                    <?php if($barbershop->latitude && $barbershop->longitude): ?>
                        <div class="bg-white p-6 rounded-lg shadow">
                            <h2 class="text-xl font-semibold mb-3 text-gray-800">Location Map</h2>
                            <iframe
                                width="100%" height="250" class="rounded"
                                frameborder="0" style="border:0"
                                src="https://www.google.com/maps/embed/v1/view?key=YOUR_GOOGLE_MAPS_API_KEY&center=<?php echo e($barbershop->latitude); ?>,<?php echo e($barbershop->longitude); ?>&zoom=15"
                                allowfullscreen>
                            </iframe>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    
    <script>
    const stars = document.querySelectorAll('.rating-stars .star');
    const ratingInput = document.getElementById('rating-value');

    stars.forEach(star => {
        star.addEventListener('click', () => {
            const value = star.dataset.value;
            ratingInput.value = value;

            stars.forEach(s => {
                const sVal = s.dataset.value;
                s.classList.remove('fas', 'far', 'text-yellow-400');
                if (sVal <= value) {
                    s.classList.add('fas', 'text-yellow-400');
                } else {
                    s.classList.add('far');
                }
            });
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\workn\OneDrive\Desktop\Work\AfroCuts\AfroCuts\resources\views/barbershops/show.blade.php ENDPATH**/ ?>