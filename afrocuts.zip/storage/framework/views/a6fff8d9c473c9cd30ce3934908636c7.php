

<?php $__env->startSection('content'); ?>

    
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    
    
    <div class="container mx-auto px-4 py-8 pt-24 relative overflow-hidden">

        
        
        <div class="absolute inset-0 z-0 opacity-10" style=" 
            background-image: url('https://img.freepik.com/premium-vector/hairdressing-barbershop-tools-seamless-pattern-beauty-salon_341076-314.jpg?w=900'); 
            background-size: 200px auto; 
            background-repeat: repeat; 
            background-position: center; 
            pointer-events: none; 
        "></div>

        
        <div class="relative z-10 bg-white rounded-lg shadow-md p-6 md:p-8"> 

            
            <div class="mb-8"> 
                <a href="<?php echo e(route('barbershops.index')); ?>" class="inline-block bg-gray-300 text-gray-800 px-4 py-2 rounded-lg font-medium hover:bg-gray-400 transition">
                    <i class="fas fa-arrow-left mr-2"></i> Back to List
                </a>
            </div>

            
            <div class="mb-8 rounded-lg overflow-hidden shadow-sm">
                 
                <?php if($barbershop->logo): ?>
                    <img src="<?php echo e(asset('storage/' . $barbershop->logo)); ?>" alt="<?php echo e($barbershop->name); ?>" class="w-full h-96 object-cover"> 
                <?php else: ?>
                    <div class="w-full h-96 bg-gray-200 flex items-center justify-center text-gray-400 text-6xl">
                        <i class="fas fa-cut"></i>
                    </div>
                <?php endif; ?>
                 
                 
            </div>

            
            <div class="mb-8 border-b pb-6 border-gray-200"> 
                <h1 class="text-4xl font-bold text-gray-800 mb-2"><?php echo e($barbershop->name); ?></h1>
                <p class="text-gray-600 text-lg flex items-center"><i class="fas fa-map-marker-alt mr-2"></i> <?php echo e($barbershop->city); ?>, <?php echo e($barbershop->state); ?></p>
                 
                 
            </div>

            
            <div class="flex flex-col md:flex-row gap-8">

                
                <div class="md:w-2/3 flex flex-col gap-8"> 
                    
                    <div class="bg-gray-50 rounded-lg p-6 shadow-sm"> 
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">About <?php echo e($barbershop->name); ?></h3>
                        <p class="text-gray-700"><?php echo e($barbershop->description); ?></p>
                    </div>

                    
                    <div class="bg-gray-50 rounded-lg p-6 shadow-sm"> 
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">Ratings & Reviews</h3>
                        <p class="text-gray-600">Ratings and reviews section coming soon...</p>
                        
                    </div>

                    
                    <div class="bg-gray-50 rounded-lg p-6 shadow-sm"> 
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">Location Map</h3>
                        <div class="bg-gray-200 h-64 rounded-lg flex items-center justify-center text-gray-600">
                            Map Placeholder
                            
                        </div>
                    </div>
                </div>

                
                <div class="md:w-1/3 flex flex-col gap-8"> 
                     
                    <?php if($barbershop->services && is_array($barbershop->services)): ?> 
                        <div class="bg-white rounded-lg shadow-md p-6"> 
                            <h3 class="text-xl font-semibold text-gray-700 mb-2">Services Offered</h3>
                            <div class="flex flex-wrap gap-2">
                                <?php $__currentLoopData = $barbershop->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     
                                     <?php if(is_array($service) && isset($service['name'])): ?>
                                         
                                        <span class="bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-sm"><?php echo $service['name']; ?></span>
                                     <?php else: ?>
                                         
                                         <span class="bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-sm"><?php echo $service; ?></span>
                                     <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <div class="bg-white rounded-lg shadow-md p-6"> 
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">Working Hours</h3>
                        <?php if($barbershop->working_hours): ?>
                            <?php $__currentLoopData = $barbershop->working_hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="text-gray-600"><?php echo e(ucfirst($day)); ?>: <?php echo e($hours); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-gray-600">Hours not specified.</p>
                        <?php endif; ?>
                    </div>

                    
                    <div class="bg-white rounded-lg shadow-md p-6"> 
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">Contact Information</h3>
                        <p class="text-gray-600 flex items-center mb-1"><i class="fas fa-map-marker-alt mr-2"></i> <?php echo e($barbershop->address); ?>, <?php echo e($barbershop->city); ?>, <?php echo e($barbershop->state); ?> <?php echo e($barbershop->zip_code); ?></p>
                        <p class="text-gray-600 flex items-center mb-1"><i class="fas fa-phone mr-2"></i> <?php echo e($barbershop->phone); ?></p>
                        <p class="text-gray-600 flex items-center"><i class="fas fa-envelope mr-2"></i> <?php echo e($barbershop->email); ?></p>

                        
                        <div class="flex items-center space-x-4 mt-4">
                            <?php if($barbershop->website): ?>
                                <a href="<?php echo e($barbershop->website); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fas fa-globe mr-2"></i> Website</a>
                            <?php endif; ?>
                            <?php if($barbershop->instagram): ?>
                                 
                                 <a href="https://www.instagram.com/<?php echo e($barbershop->instagram); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fab fa-instagram mr-2"></i> Instagram</a>
                            <?php endif; ?>
                            <?php if($barbershop->facebook): ?>
                                 
                                 <a href="https://www.facebook.com/<?php echo e($barbershop->facebook); ?>" target="_blank" class="text-gray-600 hover:text-gray-800 transition flex items-center"><i class="fab fa-facebook-f mr-2"></i> Facebook</a>
                            <?php endif; ?>
                        </div>
                    </div>


                    
                    
                    <div class="mt-auto"> 
                         <a href="<?php echo e(route('bookings.create', $barbershop->id)); ?>" class="w-full inline-block text-center bg-gray-800 text-white text-xl font-bold py-4 rounded-lg hover:bg-gray-700 transition shadow-md">
                            Book Now
                         </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\workn\OneDrive\Desktop\Work\AfroCuts\AfroCuts\resources\views/barbershops/show.blade.php ENDPATH**/ ?>