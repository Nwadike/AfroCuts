 

<?php $__env->startSection('dashboard_content'); ?> 

    
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Dashboard</h1>

    
    <?php if(Auth::user()->isBusiness()): ?>
        
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"> 

            
            
            <div class="bg-white rounded-lg shadow-xl p-6 text-center transform transition duration-300 hover:scale-105 hover:shadow-2xl"> 
                <div class="p-4 bg-blue-100 rounded-full inline-block mb-4"> 
                    <i class="fas fa-eye text-blue-600 text-3xl"></i> 
                </div>
                <p class="text-gray-700 text-lg font-semibold">Total Visitors</p>
                
                <p class="text-gray-900 text-3xl font-bold mt-1">1,234</p> 
            </div>

            
            
            <div class="bg-white rounded-lg shadow-xl p-6 text-center transform transition duration-300 hover:scale-105 hover:shadow-2xl"> 
                 <div class="p-4 bg-green-100 rounded-full inline-block mb-4"> 
                    <i class="fas fa-calendar-check text-green-600 text-3xl"></i> 
                </div>
                <p class="text-gray-700 text-lg font-semibold">Total Bookings</p>
                 
                <p class="text-gray-900 text-3xl font-bold mt-1">567</p> 
            </div>

            
            
            <div class="bg-white rounded-lg shadow-xl p-6 text-center transform transition duration-300 hover:scale-105 hover:shadow-2xl"> 
                 <div class="p-4 bg-yellow-100 rounded-full inline-block mb-4"> 
                    <i class="fas fa-dollar-sign text-yellow-600 text-3xl"></i> 
                </div>
                <p class="text-gray-700 text-lg font-semibold">Total Revenue</p>
                 
                <p class="text-gray-900 text-3xl font-bold mt-1">$12,345</p> 
            </div>
        </div>

        
        <div class="text-center mb-8"> 
            
            <a href="<?php echo e(route('barbershop.analytics.index')); ?>" class="text-gray-800 hover:underline font-semibold text-lg">View Detailed Analytics & Reports <i class="fas fa-arrow-right ml-1 text-sm"></i></a>
        </div>

        
        
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Your Barbershop Details</h2>
            <?php if(Auth::user()->barbershop): ?>
                <p class="text-gray-600 mb-2"><span class="font-semibold">Barbershop Name:</span> <?php echo e(Auth::user()->barbershop->name); ?></p>
                <p class="text-gray-600 mb-2"><span class="font-semibold">Email:</span> <?php echo e(Auth::user()->barbershop->email); ?></p>
                <p class="text-gray-600 mb-2"><span class="font-semibold">Phone:</span> <?php echo e(Auth::user()->barbershop->phone ?? 'N/A'); ?></p>
                <p class="text-gray-600 mb-2"><span class="font-semibold">Address:</span> <?php echo e(Auth::user()->barbershop->address); ?>, <?php echo e(Auth::user()->barbershop->city); ?>, <?php echo e(Auth::user()->barbershop->state); ?> <?php echo e(Auth::user()->barbershop->zip_code); ?></p>
                 <p class="text-gray-600 mb-2"><span class="font-semibold">Approval Status:</span> <span class="font-bold text-<?php echo e(Auth::user()->barbershop->is_approved ? 'green' : 'red'); ?>-600"><?php echo e(Auth::user()->barbershop->is_approved ? 'Approved' : 'Pending Approval'); ?></span></p>
                
            <?php else: ?>
                <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
                    <p class="font-bold">Barbershop Profile Incomplete</p>
                    <p>Please complete your <a href="<?php echo e(route('barbershops.create.initial')); ?>" class="text-blue-600 hover:underline">barbershop profile</a> to start managing your business and receiving bookings.</p>
                </div>
            <?php endif; ?>
        </div>


         
         <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Bookings Received</h2>

            <?php if(isset($receivedBookings) && $receivedBookings->count()): ?>
                <div class="space-y-6">
                    <?php $__currentLoopData = $receivedBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <div class="bg-gray-100 rounded-lg p-4 shadow-sm">
                            <h3 class="text-xl font-bold text-gray-800 mb-2">Booking from <?php echo e($booking->user->name); ?></h3>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Date:</span> <?php echo e($booking->date->format('M d, Y')); ?></p>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Time:</span> <?php echo e(ucfirst($booking->time_slot)); ?></p>
                             <p class="text-gray-700 mb-1"><span class="font-semibold">Services:</span>
                                
                                <?php if(is_array($booking->services)): ?>
                                    
                                    <?php $__currentLoopData = $booking->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($service['name']); ?> <?php if(isset($service['staff_name']) && $service['staff_name']): ?> (<?php echo e($service['staff_name']); ?>) <?php endif; ?> <?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    N/A 
                                <?php endif; ?>
                            </p>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Total:</span> $<?php echo e(number_format($booking->total_amount, 2)); ?></p>
                            <?php if($booking->notes): ?>
                                <p class="text-gray-700 mb-1"><span class="font-semibold">Note:</span> <?php echo e($booking->notes); ?></p>
                            <?php endif; ?>
                            <p class="text-gray-700"><span class="font-semibold">Status:</span> <span class="font-bold text-blue-600"><?php echo e(ucfirst($booking->status)); ?></span></p>

                            
                             
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="mt-6">
                    <?php echo e($receivedBookings->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-gray-100 rounded-lg p-4 text-center text-gray-600">
                    <p class="text-lg mb-4">You have not received any bookings yet.</p>
                     
                    <?php if(Auth::user()->isBusiness() && !Auth::user()->barbershop): ?>
                        <p>Complete your <a href="<?php echo e(route('barbershops.create.initial')); ?>" class="text-blue-600 hover:underline">barbershop profile</a> to start receiving bookings.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <?php if(Auth::user()->isRegular()): ?>
         
        
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Your Details</h2>
            <p class="text-gray-600 mb-2"><span class="font-semibold">Name:</span> <?php echo e(Auth::user()->name); ?></p>
            <p class="text-gray-600 mb-2"><span class="font-semibold">Email:</span> <?php echo e(Auth::user()->email); ?></p>
             <p class="text-gray-600 mb-2"><span class="font-semibold">Account Type:</span> <?php echo e(ucfirst(Auth::user()->account_type)); ?></p>
            
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Your Bookings</h2>

            <?php if(isset($bookings) && $bookings->count()): ?>
                <div class="space-y-6">
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <div class="bg-gray-100 rounded-lg p-4 shadow-sm">
                            <h3 class="text-xl font-bold text-gray-800 mb-2"><?php echo e($booking->barbershop->name); ?></h3>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Date:</span> <?php echo e($booking->date->format('M d, Y')); ?></p> 
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Time:</span> <?php echo e(ucfirst($booking->time_slot)); ?></p>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Services:</span>
                                
                                <?php if(is_array($booking->services)): ?>
                                    
                                    <?php $__currentLoopData = $booking->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($service['name']); ?> <?php if(isset($service['staff_name']) && $service['staff_name']): ?> (<?php echo e($service['staff_name']); ?>) <?php endif; ?> <?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    N/A 
                                <?php endif; ?>
                            </p>
                            <p class="text-gray-700 mb-1"><span class="font-semibold">Total:</span> $<?php echo e(number_format($booking->total_amount, 2)); ?></p> 
                            <?php if($booking->notes): ?>
                                <p class="text-gray-700 mb-1"><span class="font-semibold">Note:</span> <?php echo e($booking->notes); ?></p>
                            <?php endif; ?>
                            <p class="text-gray-700"><span class="font-semibold">Status:</span> <span class="font-bold text-blue-600"><?php echo e(ucfirst($booking->status)); ?></span></p> 

                            
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="mt-6">
                    <?php echo e($bookings->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-gray-100 rounded-lg p-4 text-center text-gray-600">
                    <p>You have no bookings yet.</p>
                     <p class="mt-4">Find a barbershop and <a href="<?php echo e(route('barbershops.index')); ?>" class="text-blue-600 hover:underline">make a booking</a>!</p> 
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\workn\OneDrive\Desktop\Work\AfroCuts\AfroCuts\resources\views/users/dashboard.blade.php ENDPATH**/ ?>